REAPER timing repair — Studio revision 17

Save Verdict Of The Lamb_Studio17_Review.rpp BESIDE your original project,
in the same folder. Open the new project in REAPER. Its Media\... references
are unchanged. Your original project is untouched.

All first 15 manually adjusted lyric markers are preserved exactly. The
remaining 72 marker positions use the new mix + vocal alignment. Regions
follow the resulting section/lyric boundaries; Intro stays at project zero.
All non-marker project content is byte-identical: tracks, media, source
offsets, playback rates, effects, routing, levels and editing state.

The new algorithm was tested on the exact analysis audio from your evidence
pack. BEFORE overlaying your corrections, the 15 reference markers had mean
absolute error 0.206 s (previously 1.061 s); 14/15 were within 0.5 s.
The first growled double-Guilty line remains 1.526 s late in raw Studio output;
YOUR correct marker for it is retained in this project. The remaining 72
markers have no independently confirmed reference positions. They are improved
estimates to review, not verified word-accurate timestamps.

Studio17_marker_comparison.csv distinguishes confirmed reference positions
from unchanged old project estimates. The marker CSV is an alternative import;
do not import it on top of the supplied project because that would duplicate
markers. The supplied RPP already contains the markers and regions.

No audio files are embedded, converted or edited by this project repair.
